export const ERROR_ROUTES = [
  {
    path: 'error',
    component: Error,
  },
];
