import { PageNotFound } from './page-not-found';

export const STATIC_ROUTES = [{ path: '**', component: PageNotFound }];
