import { Component } from '@angular/core';

@Component({
  selector: 'app-add-blog',
  imports: [],
  templateUrl: './add-blog-page.html',
  styleUrl: './add-blog-page.scss',
})
export default class AddBlogPage {}
