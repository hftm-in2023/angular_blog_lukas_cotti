export const environment = {
  production: false,
  serviceUrl:
    'https://d-cap-blog-backend---v2.whitepond-b96fee4b.westeurope.azurecontainerapps.io',
};
